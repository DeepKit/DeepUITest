import asyncio
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

import asyncpg
from dotenv import load_dotenv
import os


def database_url_for(db_name: str) -> str:
    database_url = os.getenv("DATABASE_URL")
    if not database_url:
        raise RuntimeError("DATABASE_URL is not set. Export it or load it from .env before running init_db.py.")
    parts = urlsplit(database_url)
    return urlunsplit((parts.scheme, parts.netloc, f"/{db_name}", parts.query, parts.fragment))


async def init_db() -> None:
    load_dotenv()
    story_url = database_url_for("story")
    postgres_url = database_url_for("postgres")

    sys_conn = await asyncpg.connect(postgres_url)
    try:
        await sys_conn.execute("CREATE DATABASE story")
        print("[+] Database story created.")
    except asyncpg.exceptions.DuplicateDatabaseError:
        print("[*] Database story already exists.")
    finally:
        await sys_conn.close()

    schema_path = Path(__file__).with_name("schema.sql")
    story_conn = await asyncpg.connect(story_url)
    try:
        await story_conn.execute(schema_path.read_text(encoding="utf-8"))
        print("[+] schema.sql applied.")
    finally:
        await story_conn.close()


if __name__ == "__main__":
    asyncio.run(init_db())
