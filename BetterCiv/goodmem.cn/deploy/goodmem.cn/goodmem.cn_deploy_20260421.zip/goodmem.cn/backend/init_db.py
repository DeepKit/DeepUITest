import asyncio
import asyncpg
import sys

PASSWORDS = ["a29806588", "a29806588-run"]

async def try_connect_and_create():
    valid_password = None
    for pwd in PASSWORDS:
        print(f"[*] 正在尝试密码: {pwd} ...")
        try:
            sys_conn = await asyncpg.connect(f'postgresql://postgres:{pwd}@localhost:5432/postgres')
            print(f"[+] 密码正确！已连接到 postgres 系统库。")
            valid_password = pwd
            
            try:
                await sys_conn.execute('CREATE DATABASE story')
                print("[+] ✅ 成功：数据库 [story] 创建完毕！")
            except asyncpg.exceptions.DuplicateDatabaseError:
                print("[-] 🟡 提示：数据库 [story] 已经存在。")
            finally:
                await sys_conn.close()
            break
        except Exception as e:
            print(f"[-] 密码 {pwd} 连接失败: {e}")
            
    if not valid_password:
        print("[!] 🔴 致命错误：所有密码均无法连接。请检查 PG 服务状态或密码。")
        sys.exit(1)
        
    print("\n[*] 准备向 [story] 植入 schema.sql ...")
    try:
        story_conn = await asyncpg.connect(f'postgresql://postgres:{valid_password}@localhost:5432/story')
        with open('schema.sql', 'r', encoding='utf-8') as f:
            sql_script = f.read()
            
        await story_conn.execute(sql_script)
        print("[+] ✅ 成功：[schema.sql] 结构表加载完毕！")
        await story_conn.close()
    except Exception as e:
        print(f"[-] 🔴 错误：读取或执行 schema.sql 时发生异常。\n({e})")

if __name__ == '__main__':
    asyncio.run(try_connect_and_create())
