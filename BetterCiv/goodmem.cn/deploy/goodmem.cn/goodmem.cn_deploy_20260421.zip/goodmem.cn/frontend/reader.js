// Reader 脚本已暂时并入 frontend/index.html。
// 当前文件保留为空实现，避免旧版承接逻辑与旧文案继续被误用。
